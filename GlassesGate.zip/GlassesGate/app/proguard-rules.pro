# Add project specific ProGuard rules here.
# No custom rules needed yet - isMinifyEnabled is false for the release build type.
