package com.glassesgate.app.admin

import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject

data class ApprovedDevice(
    val label: String,
    val deviceIdentifier: String,
    val secret: ByteArray,
) {
    // ByteArray in a data class needs these; the generated ones compare references.
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ApprovedDevice) return false
        return label == other.label &&
            deviceIdentifier == other.deviceIdentifier &&
            secret.contentEquals(other.secret)
    }

    override fun hashCode(): Int {
        var result = label.hashCode()
        result = 31 * result + deviceIdentifier.hashCode()
        result = 31 * result + secret.contentHashCode()
        return result
    }
}

/**
 * Local-only (no cloud, no backend) store of glasses this Admin device has enrolled, backed by
 * EncryptedSharedPreferences so the per-device secrets aren't sitting around in plaintext.
 *
 * Each admin device keeps its own independent list -- enrolling on one gate doesn't enroll on
 * another. That's the tradeoff of the fully-offline design.
 */
class ApprovedDeviceStore(context: Context) {

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "glassesgate_approved_devices",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    fun all(): List<ApprovedDevice> =
        prefs.all.mapNotNull { (key, value) ->
            runCatching {
                val json = JSONObject(value as String)
                ApprovedDevice(
                    label = json.getString("label"),
                    deviceIdentifier = key,
                    secret = Base64.decode(json.getString("secret"), Base64.NO_WRAP),
                )
            }.getOrNull()
        }.sortedBy { it.label }

    fun add(device: ApprovedDevice) {
        val json = JSONObject()
            .put("label", device.label)
            .put("secret", Base64.encodeToString(device.secret, Base64.NO_WRAP))
        prefs.edit().putString(device.deviceIdentifier, json.toString()).apply()
    }

    fun remove(deviceIdentifier: String) {
        prefs.edit().remove(deviceIdentifier).apply()
    }
}
