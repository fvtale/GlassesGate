package com.glassesgate.app.enrollment

import android.util.Base64
import org.json.JSONObject

/**
 * What the User app encodes into a QR code, and the Admin app decodes, during one-time
 * enrollment. Carries the glasses' DAT device identifier and a shared secret -- nothing from
 * Meta's servers, purely local to these two apps.
 *
 * The QR contains a live credential: anyone who photographs it can impersonate the user's
 * beacon. Show it only to the admin who is enrolling you, and rotate the secret
 * (EnrollmentSecretStore.rotateSecret) if you think it's been captured.
 */
data class EnrollmentPayload(
    val label: String,
    val deviceIdentifier: String,
    val secret: ByteArray,
) {

    fun encode(): String = JSONObject()
        .put("v", VERSION)
        .put("label", label)
        .put("id", deviceIdentifier)
        .put("secret", Base64.encodeToString(secret, Base64.NO_WRAP))
        .toString()

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is EnrollmentPayload) return false
        return label == other.label &&
            deviceIdentifier == other.deviceIdentifier &&
            secret.contentEquals(other.secret)
    }

    override fun hashCode(): Int {
        var result = label.hashCode()
        result = 31 * result + deviceIdentifier.hashCode()
        result = 31 * result + secret.contentHashCode()
        return result
    }

    companion object {
        const val VERSION = 1

        fun decode(raw: String): EnrollmentPayload? = runCatching {
            val json = JSONObject(raw)
            if (json.optInt("v") != VERSION) return null
            EnrollmentPayload(
                label = json.getString("label"),
                deviceIdentifier = json.getString("id"),
                secret = Base64.decode(json.getString("secret"), Base64.NO_WRAP),
            )
        }.getOrNull()
    }
}
