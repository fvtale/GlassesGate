package com.glassesgate.app.user

import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.Context
import android.os.ParcelUuid
import androidx.annotation.RequiresPermission
import com.glassesgate.app.core.BeaconProtocol
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Broadcasts a short, rotating, HMAC-based proof-of-active-session over BLE so an Admin device
 * (running BeaconScanner) can verify this phone currently has an approved pair of glasses
 * connected -- without either device needing internet access.
 *
 * Re-advertises every half rotation window so a scanner arriving mid-window still sees a
 * currently-valid token.
 */
class BeaconAdvertiser(
    context: Context,
    private val secret: ByteArray,
    private val deviceIdentifier: String,
) {

    private val adapter =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var job: Job? = null
    private val serviceUuid = ParcelUuid(UUID.fromString(BeaconProtocol.SERVICE_UUID_STRING))

    private val advertiseCallback = object : AdvertiseCallback() {}

    /**
     * Not every phone can act as a BLE peripheral. Check this before offering the beacon
     * toggle -- on unsupported hardware, fall back to the QR enrollment/verification path.
     */
    val isSupported: Boolean get() = adapter?.isMultipleAdvertisementSupported == true

    @RequiresPermission(android.Manifest.permission.BLUETOOTH_ADVERTISE)
    fun start() {
        if (!isSupported) return
        job?.cancel()
        job = scope.launch {
            while (isActive) {
                restartAdvertising()
                delay(BeaconProtocol.ROTATION_SECONDS * 1000 / 2)
            }
        }
    }

    @RequiresPermission(android.Manifest.permission.BLUETOOTH_ADVERTISE)
    fun stop() {
        job?.cancel()
        job = null
        runCatching { adapter?.bluetoothLeAdvertiser?.stopAdvertising(advertiseCallback) }
    }

    @RequiresPermission(android.Manifest.permission.BLUETOOTH_ADVERTISE)
    private fun restartAdvertising() {
        val advertiser = adapter?.bluetoothLeAdvertiser ?: return

        // Stop the previous advertisement before starting the next one, otherwise the stale
        // token keeps broadcasting alongside the fresh one.
        runCatching { advertiser.stopAdvertising(advertiseCallback) }

        val payload = BeaconProtocol.buildPayload(secret, deviceIdentifier)

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .setConnectable(false)
            .build()

        val data = AdvertiseData.Builder()
            .addServiceUuid(serviceUuid)
            .addServiceData(serviceUuid, payload)
            .setIncludeDeviceName(false)
            .build()

        runCatching { advertiser.startAdvertising(settings, data, advertiseCallback) }
    }
}
