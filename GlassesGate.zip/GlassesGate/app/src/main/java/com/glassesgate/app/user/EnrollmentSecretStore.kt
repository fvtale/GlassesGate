package com.glassesgate.app.user

import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom

/**
 * Stores this phone's own beacon secret(s), keyed by glasses device identifier. Generated once
 * on first use and reused for as long as that pair of glasses stays enrolled, so an admin who
 * scanned the QR yesterday still validates today.
 */
class EnrollmentSecretStore(context: Context) {

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "glassesgate_user_secrets",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    fun secretFor(deviceIdentifier: String): ByteArray {
        prefs.getString(deviceIdentifier, null)?.let { return Base64.decode(it, Base64.NO_WRAP) }
        val fresh = ByteArray(32).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString(deviceIdentifier, Base64.encodeToString(fresh, Base64.NO_WRAP))
            .apply()
        return fresh
    }

    /** Invalidates the secret, which revokes every admin device that enrolled this pair. */
    fun rotateSecret(deviceIdentifier: String): ByteArray {
        prefs.edit().remove(deviceIdentifier).apply()
        return secretFor(deviceIdentifier)
    }
}
