package com.glassesgate.app

import android.app.Application
import com.meta.wearable.dat.core.Wearables

class GlassesGateApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Must happen once per process, before any other Wearables API call.
        // Calling other DAT APIs first yields WearablesError.NOT_INITIALIZED.
        Wearables.initialize(this)
    }
}
