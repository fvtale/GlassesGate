package com.glassesgate.app.admin

import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.ParcelUuid
import androidx.annotation.RequiresPermission
import com.glassesgate.app.core.BeaconProtocol
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

sealed class BeaconState {
    /** No approved beacon in range -- the gate shows red. */
    data object Red : BeaconState()

    /** An approved beacon was verified within the last rotation window -- the gate shows green. */
    data class Green(val label: String) : BeaconState()
}

/**
 * Scans for the BeaconAdvertiser signal from any User phone and checks it against the locally
 * stored approved-device list. Entirely offline -- no server round trip.
 */
class BeaconScanner(
    context: Context,
    private val approvedStore: ApprovedDeviceStore,
) {

    private val adapter =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private val _state = MutableStateFlow<BeaconState>(BeaconState.Red)
    val state: StateFlow<BeaconState> = _state.asStateFlow()

    private val serviceUuid = ParcelUuid(UUID.fromString(BeaconProtocol.SERVICE_UUID_STRING))
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    @Volatile private var lastMatchAt = 0L
    private var watchdogJob: Job? = null

    // Read once per scan session rather than on every advertisement packet -- decrypting the
    // whole store inside onScanResult would be wasteful at LOW_LATENCY scan rates.
    @Volatile private var approvedSnapshot: List<ApprovedDevice> = emptyList()

    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val data = result.scanRecord?.getServiceData(serviceUuid) ?: return
            if (data.size < BeaconProtocol.PAYLOAD_BYTES) return

            val tag = data.copyOfRange(0, BeaconProtocol.TAG_BYTES)
            val token = data.copyOfRange(BeaconProtocol.TAG_BYTES, BeaconProtocol.PAYLOAD_BYTES)

            val match = approvedSnapshot.firstOrNull { approved ->
                BeaconProtocol.matches(tag, token, approved.deviceIdentifier, approved.secret)
            } ?: return

            lastMatchAt = System.currentTimeMillis()
            _state.value = BeaconState.Green(match.label)
        }
    }

    @RequiresPermission(android.Manifest.permission.BLUETOOTH_SCAN)
    fun start() {
        approvedSnapshot = approvedStore.all()
        _state.value = BeaconState.Red
        lastMatchAt = 0L

        val filter = ScanFilter.Builder().setServiceUuid(serviceUuid).build()
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()
        adapter?.bluetoothLeScanner?.startScan(listOf(filter), settings, callback)

        // ScanCallback only fires on a hit. Without a watchdog the UI would stay green forever
        // after the approved phone walks away, so revert to red once a full rotation window has
        // elapsed with no fresh match.
        watchdogJob = scope.launch {
            while (isActive) {
                delay(1000)
                val stale = System.currentTimeMillis() - lastMatchAt >
                    BeaconProtocol.ROTATION_SECONDS * 1000
                if (_state.value is BeaconState.Green && stale) {
                    _state.value = BeaconState.Red
                }
            }
        }
    }

    @RequiresPermission(android.Manifest.permission.BLUETOOTH_SCAN)
    fun stop() {
        watchdogJob?.cancel()
        watchdogJob = null
        runCatching { adapter?.bluetoothLeScanner?.stopScan(callback) }
        _state.value = BeaconState.Red
    }
}
