package com.glassesgate.app.user

import android.app.Activity
import com.meta.wearable.dat.core.Wearables
import com.meta.wearable.dat.core.selectors.AutoDeviceSelector
import com.meta.wearable.dat.core.session.DeviceSession

/**
 * Thin wrapper around the Meta Wearables Device Access Toolkit for the "User" role.
 *
 * NOTE: the DAT SDK is a developer-preview product and exact type/package names have moved
 * between versions (see wearables.developer.meta.com/docs/reference/android/dat). This wrapper
 * targets the surface documented for DAT 0.9. If your installed version differs, the fix is
 * almost always a rename here, not a redesign.
 *
 * In particular, verify `session.device.identifier` against your version's DeviceSession/Device
 * reference before treating it as a stable long-term "serial number" for enrollment -- if that
 * identifier rotates across reconnects, enrollment would need to be redone each time.
 */
object GlassesSessionManager {

    /** Meta AI registration state (registered / not registered / pending). */
    val registrationState get() = Wearables.registrationState

    /** Glasses currently visible to this phone via the Meta AI app. */
    val connectedDevices get() = Wearables.devices

    private var activeSession: DeviceSession? = null

    val hasActiveSession: Boolean get() = activeSession != null

    fun registerWithMetaAi(activity: Activity) {
        Wearables.startRegistration(activity)
    }

    fun unregisterFromMetaAi(activity: Activity) {
        Wearables.startUnregistration(activity)
    }

    /**
     * Starts a session with whichever registered device is connected, returning the device
     * identifier to use as the "serial" for enrollment and beacon purposes.
     */
    fun startSession(): Result<String> =
        Wearables.createSession(AutoDeviceSelector()).fold(
            onSuccess = { session ->
                session.start()
                activeSession = session
                Result.success(session.device.identifier.toString())
            },
            onFailure = { error -> Result.failure(RuntimeException(error.description)) },
        )

    fun stopSession() {
        activeSession?.stop()
        activeSession = null
    }
}
