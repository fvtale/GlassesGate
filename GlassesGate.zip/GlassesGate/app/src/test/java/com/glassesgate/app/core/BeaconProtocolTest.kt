package com.glassesgate.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * BeaconProtocol is pure JVM logic (no Android framework calls), so it runs as a plain
 * unit test without Robolectric or a device.
 */
class BeaconProtocolTest {

    private val secret = ByteArray(32) { it.toByte() }
    private val otherSecret = ByteArray(32) { (it + 1).toByte() }
    private val deviceId = "device-abc-123"
    private val now = 1_700_000_000_000L

    @Test
    fun `payload is the expected length`() {
        val payload = BeaconProtocol.buildPayload(secret, deviceId, now)
        assertEquals(BeaconProtocol.PAYLOAD_BYTES, payload.size)
    }

    @Test
    fun `matching token in the current window is accepted`() {
        val payload = BeaconProtocol.buildPayload(secret, deviceId, now)
        val tag = payload.copyOfRange(0, BeaconProtocol.TAG_BYTES)
        val token = payload.copyOfRange(BeaconProtocol.TAG_BYTES, BeaconProtocol.PAYLOAD_BYTES)

        assertTrue(BeaconProtocol.matches(tag, token, deviceId, secret, now))
    }

    @Test
    fun `token from the previous window is still accepted`() {
        val previous = now - BeaconProtocol.ROTATION_SECONDS * 1000
        val payload = BeaconProtocol.buildPayload(secret, deviceId, previous)
        val tag = payload.copyOfRange(0, BeaconProtocol.TAG_BYTES)
        val token = payload.copyOfRange(BeaconProtocol.TAG_BYTES, BeaconProtocol.PAYLOAD_BYTES)

        assertTrue(BeaconProtocol.matches(tag, token, deviceId, secret, now))
    }

    @Test
    fun `stale token from two windows ago is rejected`() {
        val stale = now - BeaconProtocol.ROTATION_SECONDS * 1000 * 3
        val payload = BeaconProtocol.buildPayload(secret, deviceId, stale)
        val tag = payload.copyOfRange(0, BeaconProtocol.TAG_BYTES)
        val token = payload.copyOfRange(BeaconProtocol.TAG_BYTES, BeaconProtocol.PAYLOAD_BYTES)

        assertFalse(BeaconProtocol.matches(tag, token, deviceId, secret, now))
    }

    @Test
    fun `token signed with a different secret is rejected`() {
        val payload = BeaconProtocol.buildPayload(otherSecret, deviceId, now)
        val tag = payload.copyOfRange(0, BeaconProtocol.TAG_BYTES)
        val token = payload.copyOfRange(BeaconProtocol.TAG_BYTES, BeaconProtocol.PAYLOAD_BYTES)

        assertFalse(BeaconProtocol.matches(tag, token, deviceId, secret, now))
    }

    @Test
    fun `token for a different device is rejected`() {
        val payload = BeaconProtocol.buildPayload(secret, "some-other-device", now)
        val tag = payload.copyOfRange(0, BeaconProtocol.TAG_BYTES)
        val token = payload.copyOfRange(BeaconProtocol.TAG_BYTES, BeaconProtocol.PAYLOAD_BYTES)

        assertFalse(BeaconProtocol.matches(tag, token, deviceId, secret, now))
    }

    @Test
    fun `device tag does not leak the raw identifier`() {
        val tag = BeaconProtocol.deviceTag(deviceId)
        assertEquals(BeaconProtocol.TAG_BYTES, tag.size)
        assertFalse(String(tag).contains(deviceId))
    }

    @Test
    fun `token rotates between windows`() {
        val a = BeaconProtocol.tokenFor(secret, deviceId, 100L)
        val b = BeaconProtocol.tokenFor(secret, deviceId, 101L)
        assertFalse(a.contentEquals(b))
    }
}
