plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.glassesgate.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.glassesgate.app"
        // BLE peripheral (advertising) mode + EncryptedSharedPreferences want a reasonably
        // modern floor; bump further if you don't need to support older devices at all.
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"

        manifestPlaceholders["mwdatApplicationId"] =
            (project.findProperty("MWDAT_APPLICATION_ID") ?: "0").toString()
        manifestPlaceholders["mwdatClientToken"] =
            (project.findProperty("MWDAT_CLIENT_TOKEN") ?: "0").toString()
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.security.crypto)
    implementation(libs.androidx.camera.core)
    implementation(libs.androidx.camera.camera2)
    implementation(libs.androidx.camera.lifecycle)
    implementation(libs.androidx.camera.view)
    implementation(libs.mlkit.barcode.scanning)
    implementation(libs.zxing.core)
    implementation(libs.kotlinx.coroutines.android)

    // Meta Wearables Device Access Toolkit
    implementation(libs.mwdat.core)
    debugImplementation(libs.mwdat.mockdevice)

    testImplementation(libs.junit)
}
